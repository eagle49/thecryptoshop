$(document).ready(function() {
    var clock = new FlipClock($('.countdown-cont'), 900, {
        autoPlay: false,
        // Create a minute counter
        clockFace: 'MinuteCounter',
        countdown: true,
    
        // The onStart callback
        onStart: function() {
            // Do something
            console.log('onStart');
        },
    
        // The onStop callback
        onStop: function() {
            // Do something
            console.log('onStop');
        },
    
        // The onReset callback
        onReset: function() {
            // Do something
            console.log('onReset');
        }
    });
    
    /**
     * see if the order is approved or in pending
     * @param {*} order_id 
     */
    function bindOrderStatus( order_id ) {
        var price = $('.coin-price').html();
        console.log("BindOrderStatus", order_id);
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            type: "POST",
            url: '/coins/orderStatus',
            data: {
                orderId: order_id,
            },
            success: function(response) {
                var res = response.split(":");
                if ( res[0] == 'pending' ) {
                    setTimeout(bindOrderStatus, 5000, order_id);
                } else {
                    var coin_cost = res[1];  // £50
                    var coin_price = res[2];  // 0.082
                    var fee_type = res[3];  // 1: fixed 2: percent
                    var fee = res[4];       // £2, 2.5%
                    var payment_info = res[5]; //
                    var cal_price = coin_cost - fee;   //£48
                    if ( fee_type == 2 ) {
                        cal_price = coin_cost - (coin_cost * fee / 100);
                    }
                    var cal_cost =parseFloat( cal_price / price ).toFixed(4);

                    $('.confirm-orderid').html(order_id);
                    $('.confirm-cost').html(coin_cost);
                    $('.confirm-price').html(cal_cost);
                    $('.confirm-payment-inf').html(payment_info);

                    console.log(coin_cost, coin_price, payment_info);

                    $("#step-wait").animate({opacity:0}, 500, function(){
                        $("#step-wait").hide();
                    });
                    $("#step-confirm").animate({opacity:1}, 500, function(){
                        $("#step-confirm").show();
                    });
                }
            },
            failure: function(error) {
                console.log("error", error);
            }
        });
    }
    $(".buy-button").on("click", function(){
        if ( !validate_input() )
            return;
        clock.start();
        var price = $('.coin-price').html();
        var tag = $('.coin-tag').html();
        var gbpval = $('.buy-pounds').val().replace('£', '');
        var crypto_price = $('.buy-crypto').val().replace(tag, '');
        console.log(price, tag, gbpval, crypto_price);

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            },
            type: "POST",
            url: '/coins/',
            data: {
                total: $('.coin-price').html(),
                wallet: $('.buy-wallet').val(),
                tag: tag,
                coin_price: gbpval,
                crypto_price: crypto_price,
                email: $('.buy-email').val(),
                fname: $('.buy-fname').val(),
                sname: $('.buy-sname').val(),
            },
            success: function(response) {
                var order_id = response;
                console.log("order_id=", order_id);
                setTimeout(bindOrderStatus, 1000, order_id);
            },
            failure: function(error) {
                console.log("error", error);
            }
        });
        
        $("#step-order").animate({opacity:0}, 500, function(){
            $("#step-order").hide();
        });
        $("#step-wait").animate({opacity:1}, 500, function(){
            $("#step-wait").show();
        });
    });

    $(".buy-pound").on("input", function() {
        
    });
    
    var parseInput = function(val) {
        var floatValue = parseFloat(val);
        return isNaN(floatValue) ? '' : floatValue;
      }
      
    $('.buy-pounds').on('input change', function(){
        var price = $('.coin-price').html();
        var tag = $('.coin-tag').html();
        var gbpval = $(this).val().replace('£', ''),
        min = parseInt(minOrder),
        max = parseInt(maxOrder);
        if(!isNaN(gbpval) && gbpval.length != 0) {
            $(this).val('£' + gbpval);
            var cryptoval = parseFloat(gbpval / price).toFixed(4);
            $('.buy-crypto').val(cryptoval + ' ' + tag);
            
            if(gbpval >= min && gbpval <= max) {
                $(this).removeClass('invalid-form');
                $('.buy-crypto').removeClass('invalid-form');
            } else {
                $(this).addClass('invalid-form');
                $('.buy-crypto').addClass('invalid-form');
            }
        } else {
            $(this).addClass('invalid-form');
            $('.buy-crypto').addClass('invalid-form');
        }
    });

    function validate_input() {
        var ret = true;
        
        if ( $('.buy-wallet').hasClass('invalid-form') || ($('.buy-wallet').val() == '') ) {
            $('.buy-wallet').addClass('invalid-form');
            ret = false;
        }

        if ( $('.buy-pounds').hasClass('invalid-form') || ($('.buy-pounds').val() == '') ) {
            $('.buy-pounds').addClass('invalid-form');
            ret = false;
        }

        if ( $('.buy-email').hasClass('invalid-form') || ($('.buy-email').val() == '') ) {
            $('.buy-email').addClass('invalid-form');
            ret = false;
        }

        if ( $('.buy-fname').val() == '' ) {
            $('.buy-fname').addClass('invalid-form');
            ret = false;
        }

        if ( $('.buy-sname').val() == '' ) {
            $('.buy-sname').addClass('invalid-form');
            ret = false;
        }
        return ret;
    }
    /* jQuery Validate Wallet Address with Regex */
    function validateWalletAddress( wallet ) {
        var pattern = /^[13][a-km-zA-HJ-NP-Z0-9]{26,36}/;
        return $.trim(wallet).match(pattern) ? true : false;
    };

    /* jQuery Validate Emails with Regex */
    function validateEmail(Email) {
        var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return $.trim(Email).match(pattern) ? true : false;
    }
    
    $('.buy-wallet').on('input change', function() {
        if(!validateWalletAddress($(this).val())) {
            $('.buy-wallet').addClass('invalid-form');
        } else {
            $('.buy-wallet').removeClass('invalid-form');
        }
    });

    $('.buy-email').on('input change', function() {
        if(!validateEmail($(this).val())) {
            $('.buy-email').addClass('invalid-form');
        } else {
            $('.buy-email').removeClass('invalid-form');
        }
    });

    $('.buy-fname').on('input change', function() {
        if ( !$('.buy-fname').val() ) {
            $('.buy-fname').addClass('invalid-form')
        } else {
            $('.buy-fname').removeClass('invalid-form');
        }
    });

    $('.buy-sname').on('input change', function() {
        if ( !$('.buy-sname').val() ) {
            $('.buy-sname').addClass('invalid-form')
        } else {
            $('.buy-sname').removeClass('invalid-form');
        }
    });
});