$('#form_product').bootstrapValidator({
    fields: {
        txtTitle: {
            validators: {
                notEmpty: {
                    message: 'The Product Title is required'
                }
            }
        },
        txtQuantity: {
            validators: {
                notEmpty: {
                    message: 'The Product Quantity is required'
                },
                regexp: {
                    regexp: /^[+-]?([0-9]*[.])?[0-9]+$/,
                    message: 'Enter valid currency'
                }
            }
        },
        pic_product: {
            validators: {
                notEmpty: {
                    message: 'The Product Image is required'
                }
            }
        },
        txtCode: {
            validators: {
                notEmpty: {
                    message: 'The Product Code is required'
                }
            }
        },            
    }
});
