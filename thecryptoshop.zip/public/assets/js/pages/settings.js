console.log("settings");
$('#form_settings').bootstrapValidator({
    fields: {
        txtMinOrder1: {
            validators: {
                notEmpty: {
                    message: 'Minium order1 is required'
                }
            }
        },
        txtMinOrder2: {
            validators: {
                notEmpty: {
                    message: 'Minium order2 is required'
                }
            }
        },
        txtMaxOrder1: {
            validators: {
                notEmpty: {
                    message: 'Maxium order1 is required'
                }
            }
        },
        txtMaxOrder2: {
            validators: {
                notEmpty: {
                    message: 'Maxium order2 is required'
                }
            }
        },
        
    }
});
