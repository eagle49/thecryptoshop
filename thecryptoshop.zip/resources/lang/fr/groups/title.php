<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Créer un nouveau groupe',
    'edit' 				=> 'Éditer le groupe',
    'management'	=> 'Organiser les groupes',

);
