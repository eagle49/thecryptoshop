<?php
/**
* Language file for user section titles
*
*/

return array(

	'user_profile'			=> 'Profil utilisateur',
	'first_name'			=> 'Prénom',
	'last_name'				=> 'Nom',
	'email'					=> 'E-mail',
	'phone'					=> 'Numéro de téléphone',
	'address'				=> 'Adresse',
	'city'					=> 'Ville',
	'status'				=> 'Statut',
	'created_at'			=> 'Créé le',
    'select_image'			=> 'Selectionner une image',
    'gender'				=> 'Sexe',
    'dob'					=> 'Date de naissance',
    'country'				=> 'Pays',
    'state'					=> 'Région',
    'postal'				=> 'Code postal'
    
);
