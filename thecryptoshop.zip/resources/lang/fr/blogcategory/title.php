<?php
/**
* Language file for blog section titles
*
*/

return array(

	'title'			=> 'Titre',
    'create'			=> 'Créer une nouvelle catégorie de blog',
    'edit' 				=> 'Éditer la catégorie de blog',
    'management'	=> 'Organiser les catégories de blog',
    
);
