<?php
/**
* Language file for user section titles
*
*/

return array(

	'user_profile'			=> 'Benutzer Profil',
	'first_name'			=> 'Vorname',
	'last_name'				=> 'Nachname',
	'email'					=> 'E-mail',
	'phone'					=> 'Telefon',
	'address'				=> 'Adresse',
	'city'					=> 'Stadt',
	'status'				=> 'Status',
	'created_at'			=> 'Erstellt am',
    'select_image'			=> 'Bild auswählen',
    'gender'				=> 'Geschlecht',
    'dob'					=> 'Geburtsdatum',
    'country'				=> 'Land',
    'state'					=> 'Bundesland',
    'postal'				=> 'Postleitzahl'
    
);
