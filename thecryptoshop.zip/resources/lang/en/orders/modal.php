<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Are you sure to accept this order?',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Accept',
    'title'         => 'Accept Order',

);
