<?php
/**
* Language file for blog section titles
*
*/

return array(

	'title'			=> 'Title',
	'create' => 'Create New Blog',
	'edit' => 'Edit Blog',
	'management' => 'Manage Blog',
	'add-blog' => 'Add New Blog',
	'blog' => 'Blog',
	'blogs' => 'Blogs',
	'bloglist' => 'Blogs List',
	'blogdetail' => 'Blog Details',
	'comments' => 'COMMENTS',
	'leavecomment' => 'LEAVE A COMMENT',


);
