<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Delete Group',
    'body'			=> 'Are you sure to delete this group? This operation is irreversible.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Delete',

);
