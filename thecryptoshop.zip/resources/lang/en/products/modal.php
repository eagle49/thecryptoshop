<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Are you sure to delete this Coin? This operation is irreversible.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Delete',
    'title'         => 'Delete Coin',

);
