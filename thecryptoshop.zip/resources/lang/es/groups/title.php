<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Crear un Grupo Nuevo',
    'edit' 				=> 'Editar Grupo',
    'management'	=> 'Administrar Grupos',

);
