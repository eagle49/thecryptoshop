<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Apagar Grupo',
    'body'			=> 'Tem certeza que quer apagar esse Grupo? Essa operação é irreversível.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Deletar',

);
