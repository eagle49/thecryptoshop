<?php

/**
* Language file for user delete modal
*
*/
return array(

    'body'			=> 'Tem certeza que quer apagar o usuário? Essa ação é irreversível.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Apagar',
    'title'         => 'Apagar Usuário',

);
