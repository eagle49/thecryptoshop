<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Создать новую группу',
    'edit' 				=> 'Редактирование группы',
    'management'	=> 'Управление Группами пользователей',

);
